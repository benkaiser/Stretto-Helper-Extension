/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};

var _a;
var script = document.createElement('script');
script.textContent = "var helperExtensionId = " + JSON.stringify(chrome.runtime.id);
(document.head || document.documentElement).appendChild(script);
(_a = script.parentNode) === null || _a === void 0 ? void 0 : _a.removeChild(script);

/******/ })()
;